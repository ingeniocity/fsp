<?php
require("Core.php");
session_start();
$objJSON = new JsonClass();
//ini_set('display_errors', '1');

$decoded = NULL;
$finalVal = NULL;

$decoded = json_decode($_REQUEST['JSON']);
//$decoded = json_decode($_REQUEST['JSON'] = '{"jcase":"compDataSet","container":"body_main_pane","database":"escom","tablename1":"tbl_company","tablename2":"tbl_config","query1":"UPDATE tbl_config SET ConfigValue=\'22:00-20:10,22:10-21:10,22:10-21:10\' WHERE ConfigName=\'Peak Time\'","query2":"UPDATE tbl_company SET weightage=\'53\', informHTConsumers=0, sendSMSConsumersAtmostMins=\'15\' WHERE company_name=\'BESCOM\'"}');

switch($decoded->jcase)
{
	case "setAppUnApp":
		$operation = "UPDATE";
		$mysqlData = $objJSON->executeSQL($decoded->database, $decoded->tablename, $decoded->query, $operation);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$decoded->appVal,"0"));
	break;
	
	case "historyGet":
		$operation = "SELECT";
		$mysqlData = $objJSON->executeSP($decoded->database, $decoded->tablename, $decoded->query, $operation);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$mysqlData,"0"));
	break;
	
	case "userAppr":
		$_SESSION["PageStat"] = 4;
		$operation = "UPDATE";
		$mysqlData = $objJSON->executeSP($decoded->database, $decoded->tablename, $decoded->query, $operation);
		$operation = "SELECT";
		$cQuery = "select * from tbl_company where company_id='".$decoded->compID."'";
		$mysqlData1 = $objJSON->executeSQL($decoded->database, $decoded->tablename, $cQuery, $operation);
		$finalVal = array("CDT"=>$mysqlData1, "DATA"=>$mysqlData);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$finalVal,"0"));
	break;
	
	case "userForApprov":
		$operation = "SELECT";
		$mysqlData = $objJSON->executeSQL($decoded->database, $decoded->tablename, $decoded->query, $operation);
		//print_r($mysqlData);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$mysqlData,"0"));
	break;
	
	case "grpUpdate":
		$operation = "UPDATE";
		$mysqlData = $objJSON->executeSP($decoded->database, $decoded->tablename, $decoded->query, $operation);
		//print_r($mysqlData);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$decoded->grpId,"0"));
	break;
	
	case "grpView":
		$operation = "INSERT";
		$mysqlData1 = $objJSON->executeSP($decoded->database, $decoded->tablename, $decoded->query, $operation);
		$qry2 = "SELECT Class8GeoID,FEEDER_NAME FROM tbl_feederhierarchy where GROUP_ID=".$decoded->id;
		$mysqlData2 = $objJSON->executeSP($decoded->database, $decoded->tablename, $qry2, $operation);
		$mysqlData3 = $objJSON->executeSP($decoded->database, $decoded->tablename, $decoded->query1, $operation);
		$mysqlData4 = $objJSON->executeSP($decoded->database, $decoded->tablename, $decoded->query2, $operation);
		$finalVal = array("Feeder"=>$mysqlData3, "Zone"=>$mysqlData4, "DATA1"=>$mysqlData1,"DATA2"=>$mysqlData2);
		//print_r($finalVal);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$finalVal,"0"));
	break;
	
	case "grpDelete":
		$operation = "INSERT";
		$mysqlData = $objJSON->executeSQL($decoded->database, $decoded->tablename, $decoded->query, $operation);
		//print_r($mysqlData);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$mysqlData,"0"));
	break;
	
	case "GetPOTPlan":
		$operation = "SELECT";
		$mysqlData = $objJSON->executeSP($decoded->database, $decoded->tablename, $decoded->query, $operation);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$mysqlData,"0"));
	break;
	
	case "createGrp":
		$operation = "INSERT";
		$mysqlData = $objJSON->executeSP($decoded->database, $decoded->tablename, $decoded->query, $operation);
		//print_r($mysqlData);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$mysqlData,"0"));
	break;
	
	case "getGrd":
		$operation = "SELECT";
		$mysqlData = $objJSON->executeSP($decoded->database, $decoded->tablename, $decoded->query, $operation);
		//print_r($mysqlData);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$mysqlData,"0"));
	break;
	
	case "RegetGrd":
		$operation = "SELECT";
		$mysqlData = $objJSON->executeSP($decoded->database, $decoded->tablename, $decoded->query, $operation);
		//print_r($mysqlData);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$mysqlData,"0"));
	break;
	
	case "addStation":
		$operation = "SELECT";
		$mysqlData = $objJSON->executeSP($decoded->database, $decoded->tablename, $decoded->query, $operation);
		//print_r($mysqlData);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$mysqlData,"0"));
	break;

	case "Restation":
		$operation = "SELECT";
		$mysqlData = $objJSON->executeSP($decoded->database, $decoded->tablename, $decoded->query, $operation);
		//print_r($mysqlData);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$mysqlData,"0"));
	break;

	case "addGrp":
		$operation = "SELECT";
		$mysqlData1 = $objJSON->executeSP($decoded->database, $decoded->tablename1, $decoded->query1, $operation);
		$mysqlData2 = $objJSON->executeSP($decoded->database, $decoded->tablename1, $decoded->query2, $operation);
		$finalVal = array("SP1"=>$mysqlData1,"SP2"=>$mysqlData2);
		//print_r($finalVal);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$finalVal,"0"));
	break;
	
	case "loginAuth":
		$operation = "SELECT";
		$mysqlData = $objJSON->executeSQL($decoded->database, $decoded->tablename, $decoded->query, $operation);
		if($mysqlData)
		{
			$finalData = array("UserName"=>$decoded->username);
			$operation = "UPDATE";
			$qryTimeOut = "UPDATE tbl_11kv_user SET time_out=1800 WHERE email='".$decoded->username."' OR username='".$decoded->username."'";
			$mysqlTimeData = $objJSON->executeSQL($decoded->database, $decoded->tablename, $qryTimeOut, $operation);
		}
		else
			$finalData = array("UserName"=>"Invalid");
		//print_r($finalData);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$finalData,"0"));
	break;
	
	case "time_out":
		$operation = "SELECT";
		$mysqlData = $objJSON->executeSQL($decoded->database, $decoded->tablename, $decoded->query, $operation);
		$finalData = array("TimeVal"=>$mysqlData, "UserName"=>$decoded->username);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$finalData,"0"));
	break;
	
	case "time_out_pool":
		//echo $decoded->query."____".$decoded->username;
		$operation = "UPDATE";
		$mysqlData = $objJSON->executeSQL($decoded->database, $decoded->tablename, $decoded->query, $operation);
		if($decoded->timeVal == "0")
			session_destroy();
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$decoded->username,$decoded->timeVal));
	break;
	
	case "confData":
		$_SESSION["PageStat"] = 2;
		$operation = "SELECT";
		$mysqlData1 = $objJSON->executeSQL($decoded->database, $decoded->tablename1, $decoded->query1, $operation);
		$mysqlData2 = $objJSON->executeSQL($decoded->database, $decoded->tablename2, $decoded->query2, $operation);
		$finalVal = array("DATA1"=>$mysqlData1, "DATA2"=>$mysqlData2);
		//print_r($finalVal);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$finalVal,"0"));
	break;
	
	case "confDataSet":
		$operation = "UPDATE";
		$mysqlData0 = $objJSON->executeSQL($decoded->database, $decoded->tablename, $decoded->query0, $operation);
		$mysqlData1 = $objJSON->executeSQL($decoded->database, $decoded->tablename, $decoded->query1, $operation);
		if($mysqlData0 == "SUCCESS" && $mysqlData1 == "SUCCESS")
			$finalVal = array("MSG"=>"Configuration is saved successfully!");
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$finalVal,"0"));
	break;
	
	case "userProf":
		$_SESSION["PageStat"] = 3;
		$operation = "SELECT";
		$mysqlData = $objJSON->executeSQL($decoded->database, $decoded->tablename, $decoded->query, $operation);
		//print_r($mysqlData);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$mysqlData,"0"));
	break;
	
	case "userPass":
		$operation = "UPDATE";
		$mysqlData = $objJSON->executeSQL($decoded->database, $decoded->tablename, $decoded->query, $operation);
		if($mysqlData == "SUCCESS")
			$finalVal = array("MSG"=>"Password is changed successfully!");
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$finalVal,"0"));
	break;

	case "userProfData":
		$operation = "UPDATE";
		$mysqlData = $objJSON->executeSQL($decoded->database, $decoded->tablename, $decoded->query, $operation);
		if($mysqlData == "SUCCESS")
			$finalVal = array("MSG"=>"User profile is being changed successfully!");
		else
			$finalVal = array("MSG"=>"Oops! Error creating user, try again!");
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$finalVal,"0"));
	break;
	
	case "pikTimSet":
		$operation = "UPDATE";
		$mysqlData = $objJSON->executeSQL($decoded->database, $decoded->tablename, $decoded->query, $operation);
		if($mysqlData == "SUCCESS")
			$finalVal = array("MSG"=>"Peak Hours times are configured successfully!");
		else
			$finalVal = array("MSG"=>"Oops! Error setting peak hour time, try again.");
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$finalVal,"0"));
	break;
	
	case "compDataSet":
		$operation = "UPDATE";
		$mysqlData1 = $objJSON->executeSQL($decoded->database, $decoded->tablename1, $decoded->query1, $operation);
		$mysqlData2 = $objJSON->executeSQL($decoded->database, $decoded->tablename2, $decoded->query2, $operation);
		$mysqlData3 = $objJSON->executeSQL($decoded->database, $decoded->tablename2, $decoded->query3, $operation);
		$mysqlData4 = $objJSON->executeSP($decoded->database, $decoded->tablename2, $decoded->query4, $operation);
		if($mysqlData1 == "SUCCESS" && $mysqlData2 == "SUCCESS" && $mysqlData3 == "SUCCESS")
			$finalVal = array("MSG"=>"Configuration is set successfully!");
		else
			$finalVal = array("MSG"=>"Oops! Error in configuration setting, try again.");
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$finalVal,"0"));
	break;
	
	case "grpDrop":
		$_SESSION["PageStat"] = 1;
		$operation = "SELECT";
		$mysqlData1 = $objJSON->executeSP($decoded->database, $decoded->tablename1, $decoded->query1, $operation);
		$mysqlData2 = $objJSON->executeSP($decoded->database, $decoded->tablename1, $decoded->query2, $operation);
		$finalVal = array("Feeder"=>$mysqlData1, "Zone"=>$mysqlData2);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$finalVal,"0"));
	break;
	
	case "grpDetail":
		$operation = "SELECT";
		$mysqlData = $objJSON->executeSP($decoded->database, $decoded->tablename, $decoded->query, $operation);
		//print_r($mysqlData);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$mysqlData,"0"));
	break;
	
	case "grpuser":
		$operation = "SELECT";
		$mysqlData = $objJSON->executeSQL($decoded->database, $decoded->tablename, $decoded->query, $operation);
		//print_r($mysqlData);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$mysqlData,"0"));
	break;
	
	case "zoneDrop":
		$operation = "SELECT";
		$mysqlData = $objJSON->executeSP($decoded->database, $decoded->tablename, $decoded->query, $operation);
		//print_r($mysqlData);
		die($objJSON->getJSONarray($decoded->jcase,$decoded->container,$mysqlData,"0"));
	break;
	
	
	default:
	die($objJSON->getJSONarray($decoded->jcase,$decoded->container,"","3"));
}
?>
